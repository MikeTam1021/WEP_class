import sys
import math
import random
import pygame

import data
import const
import pattern
import levels


class GameWindow(object):

    def __init__(self):
        pygame.display.set_caption('bytelife')
        self.screen = pygame.display.set_mode((2*const.WIDTH, 2*const.HEIGHT))
        try:
            pygame.mixer.init()
        except:
            print 'Cannot load music.'
        self.intro()
        # self.game(1)

    def intro(self):
        level = Intro(self, self.screen).loop()
        self.game(level)

    def game(self, level):
        restart = True
        first_run = True
        while restart:
            restart = Game(self, self.screen, level, first_run).loop()
            first_run = False
        self.intro()


class Intro(object):

    def __init__(self, window, screen):
        self.window = window
        self.real_screen = screen
        self.screen = pygame.surface.Surface((const.WIDTH, const.HEIGHT))
        self.clock = pygame.time.Clock()
        self.nlevels = 5
        self.level = 0
        self.levels = [pygame.image.load(data.filepath('l' + str(i+1) + '.png')).convert() for i in range(self.nlevels)]
        self.select_sound = pygame.mixer.Sound(data.filepath('select.wav'))
        self.select_sound.set_volume(const.SOUND_VOLUME)
        self.start_sound = pygame.mixer.Sound(data.filepath('start.wav'))
        self.start_sound.set_volume(const.SOUND_VOLUME)

    def loop(self):
        self.bg = pygame.image.load(data.filepath('intro.png')).convert()
        self.screen.blit(self.bg, (0,0))
        pygame.transform.scale(self.screen, (2*const.WIDTH, 2*const.HEIGHT), self.real_screen)
        pygame.display.update()

        self.done = False
        while not self.done:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    self.on_keydown(event)

            self.screen.blit(self.levels[self.level], (51, 151))

            pygame.transform.scale(self.screen, (2*const.WIDTH, 2*const.HEIGHT), self.real_screen)
            pygame.display.flip()
        return self.level + 1

    def on_keydown(self, event):
        if event.key == pygame.K_ESCAPE:
            sys.exit()
        elif event.key == pygame.K_LEFT or event.key == pygame.K_a:
            self.level = (self.level - 1) % self.nlevels
            self.select_sound.play()
        elif event.key == pygame.K_RIGHT or event.key == pygame.K_d:
            self.level = (self.level + 1) % self.nlevels
            self.select_sound.play()
        elif event.key == pygame.K_UP or event.key == pygame.K_w:
            self.done = True
            self.start_sound.play()


class Game(object):

    def __init__(self, window, screen, level, first_run):
        self.window = window
        self.real_screen = screen
        self.screen = pygame.surface.Surface((const.WIDTH, const.HEIGHT))
        self.clock = pygame.time.Clock()
        self.level = level
        self.lp = levels.levels[self.level-1]

        self.paused = False
        self.dead = False
        self.byte = Byte(self.lp.xor_val)
        self.bits_con = pygame.sprite.RenderUpdates()
        for bit in self.byte.bits:
            self.bits_con.add(bit)
        self.aux_bits_con = pygame.sprite.RenderUpdates()
        for bit in self.byte.aux_bits:
            self.aux_bits_con.add(bit)
        self.counter = Counter((175,175), self.lp.size)
        self.counter_con = pygame.sprite.RenderUpdates()
        self.counter_con.add(self.counter)
        self.pattern_mgr = PatternManager(self.byte, self.die, self.win, self.counter, self.lp.speed, self.lp.next_timer, self.lp.pattern)
        self.restart_msg = None
        self.restart = False

        pygame.font.init()
        self.font_small = pygame.font.Font(data.filepath('AldotheApache.ttf'), 12)
        self.font_medium = pygame.font.Font(data.filepath('AldotheApache.ttf'), 20)
        self.font_large = pygame.font.Font(data.filepath('AldotheApache.ttf'), 36)

        self.chip_img = pygame.sprite.RenderUpdates()
        chip_spr = pygame.sprite.Sprite()
        chip_spr.image = pygame.image.load(data.filepath('chip.png')).convert()
        chip_spr.image.set_colorkey((255,255,255))
        chip_spr.rect = chip_spr.image.get_rect()
        chip_spr.rect.topleft = (0,0)
        self.chip_img.add(chip_spr)

        self.start_sound = pygame.mixer.Sound(data.filepath('start.wav'))
        self.start_sound.set_volume(const.SOUND_VOLUME)
        self.lose_sound = pygame.mixer.Sound(data.filepath('lose.wav'))
        self.lose_sound.set_volume(const.SOUND_VOLUME)
        self.win_sound = pygame.mixer.Sound(data.filepath('win.wav'))
        self.win_sound.set_volume(const.SOUND_VOLUME)

        self.first_run = first_run
        if pygame.mixer.get_init() is not None:
            pygame.mixer.music.load(data.filepath('8bp104-01-receptors-speeddialer.ogg'))
            starts = [0, 45, 72, 103, 130, 150, 180, 210, 230]
            if not first_run:
                pygame.mixer.music.play(-1, random.choice(starts))
            else:
                pygame.mixer.music.play(-1, 0)

    def loop(self):
        self.bg = pygame.image.load(data.filepath('bg.png')).convert()
        self.screen.blit(self.bg, (0,0))
        pygame.transform.scale(self.screen, (2*const.WIDTH, 2*const.HEIGHT), self.real_screen)
        pygame.display.update()
        hint_timer = 6

        self.done = False
        while not self.done:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    self.on_keydown(event)
                elif event.type == pygame.KEYUP:
                    self.on_keyup(event)

            self.pattern_mgr.clear(self.screen, self.bg)
            self.chip_img.clear(self.screen, self.bg)
            self.bits_con.clear(self.screen, self.bg)
            self.aux_bits_con.clear(self.screen, self.bg)
            self.counter_con.clear(self.screen, self.bg)

            dt = self.clock.tick(const.FPS) / 1000.0

            if not self.paused:
                if not (hint_timer > 1.5 and self.level == 1 and self.first_run):
                    self.pattern_mgr.update(dt)
                self.bits_con.update(dt)
                self.aux_bits_con.update(dt)
                self.counter_con.update(dt)

            self.pattern_mgr.draw(self.screen)
            self.chip_img.draw(self.screen)
            self.bits_con.draw(self.screen)
            self.aux_bits_con.draw(self.screen)
            self.counter_con.draw(self.screen)
            if self.restart_msg is not None:
                self.screen.blit(self.restart_msg, (10, 10))
                self.screen.blit(self.font_medium.render('UP to restart, DOWN to menu', True, (255, 255, 255)), (10, 320))

            if hint_timer > 0:
                hint_timer -= dt
                if self.level == 1 and self.first_run:
                    self.screen.blit(self.font_small.render('Follow the input!', True, (255, 255, 255)), (10, 280))
                    self.screen.blit(self.font_small.render('Hint: You never have to xor and cycle at the same time', True, (255, 255, 255)), (10, 300))
                    self.screen.blit(self.font_small.render('except on level 5.', True, (255, 255, 255)), (10, 315))
                    self.screen.blit(self.font_small.render('You never need to cycle more than twice at each step.', True, (255, 255, 255)), (10, 330))

            pygame.transform.scale(self.screen, (2*const.WIDTH, 2*const.HEIGHT), self.real_screen)
            pygame.display.flip()
        return self.restart

    def pause(self):
        self.paused = not self.paused

    def on_keydown(self, event):
        if event.key == pygame.K_ESCAPE:
            if self.paused:
                sys.exit()
            else:
                self.pause()
        elif event.key == pygame.K_p:
            self.pause()
        elif event.key == pygame.K_LEFT or event.key == pygame.K_a:
            if not self.paused:
                self.byte.shift_left()
        elif event.key == pygame.K_RIGHT or event.key == pygame.K_d:
            if not self.paused:
                self.byte.shift_right()
        elif event.key == pygame.K_UP or event.key == pygame.K_w:
            if not self.paused:
                self.byte.xor()
            elif self.restart_msg is not None:
                self.restart_game()
        elif event.key == pygame.K_DOWN or event.key == pygame.K_s:
            if self.paused:
                self.to_menu()

    def on_keyup(self, event):
        pass

    def die(self, error_bits):
        self.dead = True
        self.paused = True
        self.byte.set_error_bits(error_bits)
        self.restart_msg = self.font_large.render('Segfault... Restart?', True, (255, 255, 255))
        if pygame.mixer.get_init() is not None:
            pygame.mixer.music.fadeout(200)
        self.lose_sound.play()

    def win(self):
        self.dead = True
        self.paused = True
        if self.level == 5:
            self.restart_msg = self.font_large.render('Awesome! You win!', True, (255, 255, 255))
        else:
            self.restart_msg = self.font_large.render('Level complete!', True, (255, 255, 255))
        if pygame.mixer.get_init() is not None:
            pygame.mixer.music.fadeout(200)
        self.win_sound.play()

    def restart_game(self):
        self.done = True
        self.restart = True
        self.start_sound.play()

    def to_menu(self):
        self.done = True
        self.restart = False


class Byte(object):

    def __init__(self, xor_val):
        locations = [(157, 132), (182, 132), (207, 157), (207, 182), (182, 207), (157, 207), (132, 182), (132, 157)]
        aux_locations = [(152, 126), (195, 126), (221, 152), (221, 195), (195, 221), (152, 221), (126, 195), (126, 152)]
        self.bits = [Bit(l) for l in locations]
        self.nb = len(self.bits)
        self.xor_val = xor_val
        self.aux_bits = [AuxBit(l) for l in aux_locations]
        self.update_aux_bits_xor()

    def shift_left(self):
        bit_states = [self.bits[(i+1) % self.nb].state for i in range(len(self.bits))]
        for i, bit in enumerate(self.bits):
            bit.set_state(bit_states[i])

    def shift_right(self):
        bit_states = [self.bits[(i-1) % self.nb].state for i in range(len(self.bits))]
        for i, bit in enumerate(self.bits):
            bit.set_state(bit_states[i])

    def add_one(self):
        for i in range(self.nb - 1, -1, -1):
            self.bits[i].flip()
            if self.bits[i].state:
                break

    def sub_one(self):
        for i in range(self.nb - 1, -1, -1):
            self.bits[i].flip()
            if not self.bits[i].state:
                break

    def xor(self):
        for i, bit in enumerate(self.bits):
            if self.xor_val[i]:
                self.bits[i].flip()

    def update_aux_bits_xor(self):
        for i, bit in enumerate(self.aux_bits):
            bit.set_state(self.xor_val[i])

    def get_pattern(self):
        return [bit.state for bit in self.bits]

    def get_xor_pattern(self):
        return [bit.state for bit in self.aux_bits]

    def set_error_bits(self, error_bits):
        for i, v in enumerate(error_bits):
            if v:
                self.bits[i].set_error()

    def accept(self):
        for bit in self.bits:
            bit.blink()


class Bit(pygame.sprite.Sprite):

    def __init__(self, pos):
        pygame.sprite.Sprite.__init__(self)
        self.pos = list(pos)
        self.image = pygame.surface.Surface((11, 11))
        self.rect = self.image.get_rect()
        self.rect.topleft = self.pos
        self.blink_timer = 0
        self.off()

    def update(self, dt):
        if self.blink_timer > 0:
            self.blink_timer -= dt
            if self.blink_timer <= 0:
                self.blink_timer = 0
                if self.state:
                    self.image.fill((209,51,62))
                else:
                    self.image.fill((63,34,36))

    def set_state(self, on_state):
        if on_state: self.on()
        else: self.off()

    def flip(self):
        self.set_state(not self.state)

    def and_op(self):
        if not self.state:
            self.on()
            return True
        return False

    def on(self):
        self.state = True
        self.image.fill((209,51,62))

    def off(self):
        self.state = False
        self.image.fill((63,34,36))

    def set_error(self):
        if self.state:
            self.image = pygame.image.load(data.filepath('error_on.png')).convert()
        else:
            self.image = pygame.image.load(data.filepath('error_off.png')).convert()

    def blink(self):
        self.blink_timer = 0.1
        if self.state:
            self.image.fill((227,130,137))
        else:
            self.image.fill((109,59,62))


class AuxBit(pygame.sprite.Sprite):

    def __init__(self, pos):
        pygame.sprite.Sprite.__init__(self)
        self.pos = list(pos)
        self.image = pygame.surface.Surface((3, 3))
        self.rect = self.image.get_rect()
        self.rect.topleft = self.pos
        self.off()

    def update(self, dt):
        pass

    def set_state(self, on_state):
        if on_state: self.on()
        else: self.off()

    def on(self):
        self.state = True
        self.image.fill((79,194,71))

    def off(self):
        self.state = False
        self.image.fill((20,32,19))


class PatternManager(pygame.sprite.RenderUpdates):

    def __init__(self, byte, death_fun, win_fun, counter, speed, next_timer, pattern):
        pygame.sprite.RenderUpdates.__init__(self)
        self.lines = []
        self.byte = byte
        self.timer = 1
        self.counter = counter
        self.speed = speed
        self.next_timer = next_timer
        self.last_pattern = self.byte.get_pattern()
        self.death_fun = death_fun
        self.win_fun = win_fun
        self.pattern = pattern

    def generate(self):
        patterns = list(self.pattern)
        if self.last_pattern == [False for i in range(8)]:
            patterns = ['X']
        line_pattern = [False for i in range(8)]
        while line_pattern == [False for i in range(8)] or line_pattern == self.last_pattern:
            line_pattern = pattern.apply(self.last_pattern, random.choice(patterns), self.byte.get_xor_pattern())
        line = Line(line_pattern, self.byte, self.death_fun, self.win_fun, self.counter, self.speed)
        self.last_pattern = line_pattern
        self.lines.append(line)
        for bot in line.bots:
            self.add(bot)

    def update(self, dt):
        self.timer -= dt
        if self.timer <= 0:
            self.timer = self.next_timer
            if self.counter.generated > 0:
                self.counter.decrement_generated()
                self.generate()
        for line in self.lines:
            line.update(dt)
        done_lines = [line for line in self.lines if line.done]
        for line in done_lines:
            self.lines.remove(line)
        for bot in self:
            bot.update(dt)
            if bot.done:
                self.remove(bot)


class Line(object):

    def __init__(self, pattern, byte, death_fun, win_fun, counter, speed):
        self.bots = []
        self.passed = False
        self.byte = byte
        self.start_locs = [(87,0), (262,0), (349,87), (349,262), (262,349), (87,349), (0,262), (0,87)]
        self.speed = speed
        self.death_fun = death_fun
        self.win_fun = win_fun
        self.done = False
        self.error_bits = None
        self.counter = counter
        self.generate(pattern)

    def generate(self, pattern):
        self.bots = []
        for i, v in enumerate(pattern):
            self.bots.append(Bot(self.start_locs[i], v, self.speed, i))

    def get_pattern(self):
        return [bot.state for bot in self.bots]

    def accept(self):
        self.byte.accept()
        self.counter.decrement()

    def reject(self, error_bits):
        self.death_fun(error_bits)

    def update(self, dt):
        if not self.passed and self.bots[0].passed:
            self.passed = True
            line = self.get_pattern()
            byte = self.byte.get_pattern()
            if line == byte:
                self.accept()
            else:
                self.error_bits = [line[i] != byte[i] for i in range(len(line))]
        if not self.done and self.bots[0].done:
            self.done = True
            if self.error_bits is not None:
                self.reject(self.error_bits)
            elif self.counter.count == 0:
                self.win_fun()


class Bot(pygame.sprite.Sprite):

    def __init__(self, pos, state, speed, ident):
        pygame.sprite.Sprite.__init__(self)
        self.pos = list(pos)
        self.image = pygame.surface.Surface((7, 7))
        self.rect = self.image.get_rect()
        self.rect.center = self.pos
        self.state = state
        self.done = False
        if state:
            self.image.fill((209,51,62))
        else:
            self.image.fill((63,34,36))
            self.image.set_colorkey((63,34,36))
        self.speed = speed
        if ident in [0,1]:
            self.vel = [0, speed]
        elif ident in [2,3]:
            self.vel = [-speed, 0]
        elif ident in [4,5]:
            self.vel = [0, -speed]
        elif ident in [6,7]:
            self.vel = [speed, 0]
        self.ident = ident
        self.passed = False

    def update(self, dt):
        self.pos[0] += self.vel[0] * dt
        self.pos[1] += self.vel[1] * dt
        factor = 0.75
        if self.ident == 0:
            if self.pos[1] >= 62 and self.pos[0] == 87:
                self.pos[1] = 62
                self.vel = [self.speed, 0]
            if self.pos[1] == 62 and self.pos[0] >= 162:
                self.pos[0] = 162
                # self.vel = [0, self.speed]
                self.vel = [0, self.speed*factor]
            if self.pos[1] >= 137: self.passed = True
            if self.pos[1] >= 154: self.done = True
        if self.ident == 1:
            if self.pos[1] >= 62 and self.pos[0] == 262:
                self.pos[1] = 62
                self.vel = [-self.speed, 0]
            if self.pos[1] == 62 and self.pos[0] <= 187:
                self.pos[0] = 187
                # self.vel = [0, self.speed]
                self.vel = [0, self.speed*factor]
            if self.pos[1] >= 137: self.passed = True
            if self.pos[1] >= 154: self.done = True
        if self.ident == 2:
            if self.pos[0] <= 287 and self.pos[1] == 87:
                self.pos[0] = 287
                self.vel = [0, self.speed]
            if self.pos[0] == 287 and self.pos[1] >= 162:
                self.pos[1] = 162
                # self.vel = [-self.speed, 0]
                self.vel = [-self.speed*factor, 0]
            if self.pos[0] <= 212: self.passed = True
            if self.pos[0] <= 195: self.done = True
        if self.ident == 3:
            if self.pos[0] <= 287 and self.pos[1] == 262:
                self.pos[0] = 287
                self.vel = [0, -self.speed]
            if self.pos[0] == 287 and self.pos[1] <= 187:
                self.pos[1] = 187
                # self.vel = [-self.speed, 0]
                self.vel = [-self.speed*factor, 0]
            if self.pos[0] <= 212: self.passed = True
            if self.pos[0] <= 195: self.done = True
        if self.ident == 4:
            if self.pos[1] <= 287 and self.pos[0] == 262:
                self.pos[1] = 287
                self.vel = [-self.speed, 0]
            if self.pos[1] == 287 and self.pos[0] <= 187:
                self.pos[0] = 187
                # self.vel = [0, -self.speed]
                self.vel = [0, -self.speed*factor]
            if self.pos[1] <= 212: self.passed = True
            if self.pos[1] <= 195: self.done = True
        if self.ident == 5:
            if self.pos[1] <= 287 and self.pos[0] == 87:
                self.pos[1] = 287
                self.vel = [self.speed, 0]
            if self.pos[1] == 287 and self.pos[0] >= 162:
                self.pos[0] = 162
                # self.vel = [0, -self.speed]
                self.vel = [0, -self.speed*factor]
            if self.pos[1] <= 212: self.passed = True
            if self.pos[1] <= 195: self.done = True
        if self.ident == 6:
            if self.pos[0] >= 62 and self.pos[1] == 262:
                self.pos[0] = 62
                self.vel = [0, -self.speed]
            if self.pos[0] == 62 and self.pos[1] <= 187:
                self.pos[1] = 187
                # self.vel = [self.speed, 0]
                self.vel = [self.speed*factor, 0]
            if self.pos[0] >= 137: self.passed = True
            if self.pos[0] >= 154: self.done = True
        if self.ident == 7:
            if self.pos[0] >= 62 and self.pos[1] == 87:
                self.pos[0] = 62
                self.vel = [0, self.speed]
            if self.pos[0] == 62 and self.pos[1] >= 162:
                self.pos[1] = 162
                # self.vel = [self.speed, 0]
                self.vel = [self.speed*factor, 0]
            if self.pos[0] >= 137: self.passed = True
            if self.pos[0] >= 154: self.done = True
        self.rect.center = self.pos


class Counter(pygame.sprite.Sprite):

    def __init__(self, pos, count):
        pygame.sprite.Sprite.__init__(self)
        self.font = pygame.font.Font(data.filepath('visitor2.ttf'), 20)
        self.pos = list(pos)
        self.image = pygame.surface.Surface((32, 32))
        self.count = count
        self.generated = count
        self.update_text()
        self.rect = self.image.get_rect()
        self.rect.center = self.pos

    def update(self, dt):
        pass

    def decrement(self):
        self.count -= 1
        self.update_text()

    def decrement_generated(self):
        self.generated -= 1

    def update_text(self):
        self.image.fill((0,0,0))
        self.image.set_colorkey((0,0,0))
        text = self.font.render(str(self.count), True, (255,255,255))
        width = text.get_width()
        height = text.get_height()
        self.image.blit(text, (16 - width / 2, 16 - height / 2))
