import pygame
import random

pygame.init()

screen = pygame.display.set_mode((480, 640))


class MySprite(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super(MySprite, self).__init__()
        self.rect = self.rect.copy()
        self.rect.topleft = (x, y)

class PowerUp(MySprite):
    image = pygame.image.load('PowerUp.png')
    rect = image.get_rect()

class BottomPipe(MySprite):
    image = pygame.image.load('pipe.png')
    rect = image.get_rect()

class TopPipe(MySprite):
    image = pygame.transform.flip(BottomPipe.image, False, True)
    rect = image.get_rect()


class Ground(MySprite):
    image = pygame.image.load('lava.png')
    rect = image.get_rect()


class Normal_Character(MySprite):
    normal_character = pygame.image.load('Normal_Character.png')
    mega_character = pygame.image.load('Mega_Character.png')
    mega = False
    rect = pygame.rect.Rect(0, 5, 32, 18)
    dy = 0
    image = normal_character

    def draw(self, surface, distance):
        self.rect.x = distance + 210
        surface.blit(self.image, (self.rect.x - distance, self.rect.y))

    def mega_upgrade(self):
        self.image = self.mega_character
        self.mega = True

    def mega_downgrade(self):
        self.image = self.normal_character
        self.mega = False


class ScrolledGroup(pygame.sprite.Group):
    def draw(self, surface, distance):
        for sprite in self.sprites():
            surface.blit(sprite.image, (sprite.rect.x - distance,
                sprite.rect.y))


class PipesGroup(ScrolledGroup):
    last_add = None

    def update(self, distance, pipecount):
        for pipe in self.sprites():
            if pipe.rect.right < distance:
                pipe.kill()
                pipecount = pipecount + 0.5
        if self.last_add is None:
            self.last_add = self.sprites()[-1].rect.right
        if distance > self.last_add - 300:
            self.last_add = x = distance + 480
            y = random.randint(-GAP, GAP)
            self.add(BottomPipe(x,
                640 + y - BottomPipe.rect.height + GAP))
            self.add(TopPipe(x, y - GAP))
        return pipecount


class GroundGroup(ScrolledGroup):
    def update(self, distance):
        for ground in self.sprites():
            if ground.rect.right < distance:
                ground.kill()
                self.add(Ground(self.sprites()[0].rect.right,
                    640 - Ground.rect.height))

class PowerUpGroup(ScrolledGroup):
    def update(self, distance):
        for pu in self.sprites():
            if pu.rect.right < distance:
                pu.kill()
                self.add(PowerUp(480, random.randint(128, 374)))




GAP = random.randint(32, 35)

def play():
    pipecount = 0
    font = pygame.font.Font("04B_30__.TTF", 30)
    distance = 100
    character = Normal_Character(210, 320)
    pipes = PipesGroup(BottomPipe(480, 640 - BottomPipe.rect.height + GAP),
        TopPipe(480, -GAP))
    ground = GroundGroup(Ground(0, 640 - Ground.rect.height),
        Ground(Ground.rect.width, 640 - Ground.rect.height))
    powerup = PowerUpGroup(PowerUp(480, random.randint(240, 280)))
    while 1:
        pipesurface = font.render("Pipe Count Is {}".format(pipecount), False, (255,0,0))
        character.dy += .15
        distance += 3.5

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return
                if event.key == pygame.K_SPACE:
                    character.dy = -2

        ground.update(distance)
        pipecount = pipes.update(distance, pipecount)
        character.rect.y += character.dy


        if (pygame.sprite.spritecollide(character, ground, False) or
                pygame.sprite.spritecollide(character, pipes, False)):
            print 'FAIL at distance', distance
            return

        if pygame.sprite.spritecollide(character, powerup, False):
            character.mega_upgrade()


        screen.fill((100, 100, 255))
        pipes.draw(screen, distance)
        ground.draw(screen, distance)
        character.draw(screen, distance)
        powerup.draw(screen, distance)
        screen.blit(pipesurface, (20, 20))
        pygame.display.flip()

if __name__ == '__main__':
    play()
