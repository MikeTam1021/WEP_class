The Lepidopterist
=================

Entry in PyWeek #11  <http://www.pyweek.org/11/>
Team: Universe Factory 11
Members: Cosmologicon


DEPENDENCIES:

You might need to install some of these before running the game:

  Python:     http://www.python.org/
  PyGame:     http://www.pygame.org/



RUNNING THE GAME:

On Windows or Mac OS X, locate the "run_game.pyw" file and double-click it.

Othewise open a terminal / console and "cd" to the game directory and run:

  python run_game.py



HOW TO PLAY THE GAME:

Arrow keys
Space bar


LICENSE:

All copyrights to source code and artwork are waived under a Creative Commons Zero
waiver.


