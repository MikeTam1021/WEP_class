The Evolution of Evil
===============

Entry in PyWeek #23  <http://www.pyweek.org/23/>
URL: http://pyweek.org/e/The Evolution of Evil
Team: Unicorn Markets 
Members: Mike Tamillow 
License: see LICENSE.txt

Made for pyweek competition spring 2017

Running the Game
----------------

Open a terminal / console and "cd" to the game directory and run:

  python evolution_of_evil.py


How to Play the Game
--------------------

Run away from the enemies

Spacebar will restart if you die or win.

q to quit the game.

arrow keys to move.