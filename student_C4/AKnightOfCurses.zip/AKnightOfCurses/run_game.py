#! /usr/bin/env python

from gamelib import main
main.main()
