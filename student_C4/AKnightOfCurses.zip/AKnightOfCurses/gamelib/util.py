import math
import pygame


def get_normalized_vector(source, target):
    vx = source[0] - target[0]
    vy = source[1] - target[1]
    norm = math.hypot(vx, vy)
    return (vx / norm, vy / norm)


def distance(p1, p2):
    return math.hypot(p2[0] - p1[0], p2[1] - p1[1])


def get_bb_rect(rect, bb):
    return pygame.rect.Rect(rect.x + bb.x, rect.y + bb.y, bb.width, bb.height)


def slice_sprite_sheet(image, tile_size_x, tile_size_y):
    sheet_width, sheet_height = image.get_size()
    width = int(sheet_width / tile_size_x)
    height = int(sheet_height / tile_size_y)
    images = [[None for j in xrange(width)] for i in xrange(height)]
    for i in xrange(height):
        for j in xrange(width):
            images[i][j] = image.subsurface(j * tile_size_x, i * tile_size_y, tile_size_x, tile_size_y)
    return images


class Animation(pygame.surface.Surface):
    
    def __init__(self, frames, interval):
        pygame.surface.Surface.__init__(self, frames[0].get_size(), pygame.SRCALPHA, 32)
        self.frames = frames
        if isinstance(interval, list):
            self.interval = interval
        else:
            self.interval = [interval] * len(self.frames)
        self.start()
    
    def clear(self):
        self.fill((0,0,0,0))

    def pause(self):
        self.paused = True

    def start(self):
        self.paused = False
        self.current_frame = 0
        self.timer = self.interval[self.current_frame]
        self.clear()
        self.blit(self.frames[self.current_frame], (0, 0))

    def update(self, dt):
        if self.paused:
            return
        self.timer -= dt
        if self.timer <= 0:
            self.current_frame += 1
            if self.current_frame >= len(self.frames):
                self.current_frame = 0
            self.timer = self.interval[self.current_frame]
            self.clear()
            self.blit(self.frames[self.current_frame], (0, 0))
            return self.current_frame
        return None
