import math
import random

# Difficulty tiers
def get_tier(nrun):
    if nrun <= 5:
        tier = 0
    elif nrun <= 10:
        tier = 1
    else:
        tier = 2 # three tiers is fine
    # elif nrun <= 12:
    #     tier = 2
    # else:
    #     tier = 3
    return tier

TIME_BETWEEN_SHOTS = [4, 3, 2, 1]
NUMBER_OF_SHOTS = [3, 4, 5, 6]
SHOT_TYPES = [
    ['straight', 'cone'],
    ['straight', 'cone', 'star'],
    ['straight', 'cone', 'random_cone', 'star', 'mixed'],
    ['straight', 'cone', 'random_cone', 'star', 'mixed']
]


################################
# Timing patterns (for firing) #
################################

# Update method returns True if it is time to fire

class TimingPattern(object):

    def __init__(self):
        self.attacking = False
        self.preattack_timer = 0
        self.preattack_time = 0.3
        self.preattacking = False

    def start_attacking(self): # animate to warn player of an attack
        self.attacking = True
        self.preattacking = True
        self.preattack_timer = self.preattack_time

    def end_attack(self):
        self.attacking = False
        self.preattacking = False

    def update_fire_now(self, dt):
        if self.preattacking:
            self.preattack_timer -= dt
            if self.preattack_timer <= 0:
                self.preattack_timer = 0
                self.preattacking = False


class TimingPatternSuccessiveThenWait(TimingPattern):

    def __init__(self, wait_interval, successive_interval, n_shots):
        TimingPattern.__init__(self)
        self.successive_interval = successive_interval
        self.wait_interval = wait_interval
        self.timer = wait_interval
        self.wait_mode = True
        self.n_shots = n_shots
        self.shot_counter = 0

    def update_fire_now(self, dt):
        TimingPattern.update_fire_now(self, dt)
        if self.preattacking: return
        self.timer -= dt
        if self.timer <= 0:
            if self.wait_mode:
                self.timer = self.successive_interval
                self.wait_mode = False
                self.start_attacking()
            else:
                self.shot_counter += 1
                if self.shot_counter >= self.n_shots:
                    self.shot_counter = 0
                    self.timer = self.wait_interval
                    self.wait_mode = True
                    self.end_attack()
                else:
                    self.timer = self.successive_interval
                return True
        return False



###################
# Firing patterns #
###################

class FiringPattern(object):

    def __init__(self, bullets, enemy):
        self.bullets = bullets
        self.enemy = enemy

    def fire_straight(self, origin, destination):
        vx = destination[0] - origin[0]
        vy = destination[1] - origin[1]
        norm = math.hypot(vx, vy)
        if norm > 1e-4:
            vx = vx * self.speed / norm
            vy = vy * self.speed / norm
        else:
            vx = self.speed / math.sqrt(2)
            vy = self.speed / math.sqrt(2)
        vel = [vx, vy]
        self.bullets.create(origin, vel, self.enemy.following)

    def get_target_from_angle_pos(self, origin, pos, angle_inc):
        vx = pos[0] - origin[0]
        vy = pos[1] - origin[1]
        if abs(vx) <= 1e-4:
            if vy > 0:
                angle = math.pi / 2.0
            else:
                angle = -math.pi / 2.0
        else:
            angle = math.atan2(vy, vx)
        angle += angle_inc
        return (origin[0] + math.cos(angle), origin[1] + math.sin(angle))


class FiringPatternSingleFire(FiringPattern):

    def __init__(self, bullets, speed, enemy, character):
        FiringPattern.__init__(self, bullets, enemy)
        self.speed = speed
        self.character = character

    def fire(self):
        self.fire_straight(self.enemy.rect.center, self.character.rect.center)


# Locks the character's position for successive shots
class FiringPatternSuccessiveLock(FiringPattern):

    def __init__(self, bullets, speed, enemy, character, n_shots, shot_type):
        FiringPattern.__init__(self, bullets, enemy)
        self.speed = speed
        self.character = character
        self.n_shots = n_shots
        self.shot_counter = n_shots
        self.shot_type = shot_type
        self.reposition_target()

    def reposition_target(self):
        self.target = list(self.character.rect.center)

    def fire(self):
        self.shot_counter += 1
        if self.shot_counter >= self.n_shots:
            self.shot_counter = 0
            self.reposition_target()

        if self.shot_type == 'straight':
            self.fire_straight(self.enemy.rect.center, self.target)
        elif self.shot_type == 'cone':
            self.fire_straight(self.enemy.rect.center, self.get_target_from_angle_pos(self.enemy.rect.center, self.target, 0))
            self.fire_straight(self.enemy.rect.center, self.get_target_from_angle_pos(self.enemy.rect.center, self.target, math.pi/6))
            self.fire_straight(self.enemy.rect.center, self.get_target_from_angle_pos(self.enemy.rect.center, self.target, -math.pi/6))
        elif self.shot_type == 'random_cone':
            angle = random.uniform(math.pi/6, math.pi/2)
            self.fire_straight(self.enemy.rect.center, self.get_target_from_angle_pos(self.enemy.rect.center, self.target, 0))
            self.fire_straight(self.enemy.rect.center, self.get_target_from_angle_pos(self.enemy.rect.center, self.target, angle))
            self.fire_straight(self.enemy.rect.center, self.get_target_from_angle_pos(self.enemy.rect.center, self.target, -angle))
        elif self.shot_type == 'mixed':
            if self.shot_counter % 2 == 0:
                self.fire_straight(self.enemy.rect.center, self.get_target_from_angle_pos(self.enemy.rect.center, self.target, math.pi/6))
                self.fire_straight(self.enemy.rect.center, self.get_target_from_angle_pos(self.enemy.rect.center, self.target, -math.pi/6))
            else:
                self.fire_straight(self.enemy.rect.center, self.get_target_from_angle_pos(self.enemy.rect.center, self.target, 0))
                self.fire_straight(self.enemy.rect.center, self.get_target_from_angle_pos(self.enemy.rect.center, self.target, math.pi/3))
                self.fire_straight(self.enemy.rect.center, self.get_target_from_angle_pos(self.enemy.rect.center, self.target, -math.pi/3))
        elif self.shot_type == 'star':
                self.fire_straight(self.enemy.rect.center, self.get_target_from_angle_pos(self.enemy.rect.center, self.target, 0))
                self.fire_straight(self.enemy.rect.center, self.get_target_from_angle_pos(self.enemy.rect.center, self.target, math.pi/2))
                self.fire_straight(self.enemy.rect.center, self.get_target_from_angle_pos(self.enemy.rect.center, self.target, -math.pi/2))
                self.fire_straight(self.enemy.rect.center, self.get_target_from_angle_pos(self.enemy.rect.center, self.target, math.pi))



###################
# Moving patterns #
###################

TOP_LEFT_CORNER = (64, 64)
TOP_RIGHT_CORNER = (320, 64)
BOTTOM_LEFT_CORNER = (64, 320)
BOTTOM_RIGHT_CORNER = (320, 320)

CORNERS = [TOP_LEFT_CORNER, TOP_RIGHT_CORNER, BOTTOM_LEFT_CORNER, BOTTOM_RIGHT_CORNER]
ADJ_CORNERS = {
    TOP_LEFT_CORNER : [TOP_RIGHT_CORNER, BOTTOM_LEFT_CORNER],
    TOP_RIGHT_CORNER : [TOP_LEFT_CORNER, BOTTOM_RIGHT_CORNER],
    BOTTOM_LEFT_CORNER : [TOP_LEFT_CORNER, BOTTOM_RIGHT_CORNER],
    BOTTOM_RIGHT_CORNER : [TOP_RIGHT_CORNER, BOTTOM_LEFT_CORNER]
}

TOP_WALL = (192, 64)
BOTTOM_WALL = (192, 320)
LEFT_WALL = (64, 192)
RIGHT_WALL = (320, 192)

CENTER = (192, 192)


class MovingPattern(object):

    def __init__(self, enemy, speed=0):
        self.enemy = enemy
        self.destination = None
        self.speed = speed

    def when_hit(self): # triggers when hit
        pass

    def move_to(self, pos, speed):
        self.destination = pos
        self.speed = speed

    def spawn(self):
        return TOP_WALL

    def update(self, dt):
        if self.destination:
            vx = self.destination[0] - self.enemy.pos[0]
            vy = self.destination[1] - self.enemy.pos[1]
            norm = math.hypot(vx, vy)
            if norm <= self.speed * dt:
                self.enemy.pos[0] = self.destination[0]
                self.enemy.pos[1] = self.destination[1]
                self.destination = None
            else:
                vx = vx * self.speed / norm
                vy = vy * self.speed / norm
                self.enemy.pos[0] += vx * dt
                self.enemy.pos[1] += vy * dt


class MovingPatternCornersWhenHit(MovingPattern):

    def __init__(self, enemy):
        MovingPattern.__init__(self, enemy)
        self.current_loc = random.choice(CORNERS)
        self.speed = 300

    def when_hit(self):
        self.current_loc = random.choice(ADJ_CORNERS[self.current_loc])
        self.move_to(self.current_loc, self.speed)

    def spawn(self):
        return self.current_loc


class MovingPatternBetweenCornersContinuous(MovingPattern):

    def __init__(self, enemy, tier):
        MovingPattern.__init__(self, enemy)
        if tier == 2 or tier == 3:
            self.speed = 0.5
        elif tier == 0 or tier == 1:
            self.speed = 0.25
        self.current_speed = self.speed
        self.corner1, self.corner2 = random.sample(CORNERS, 2)
        self.alpha = 1
        self.hit_timer = 0

    def spawn(self):
        return self.corner1

    def update_current_pos(self):
        self.current_pos = [self.alpha * self.corner1[0] + (1 - self.alpha) * self.corner2[0],
                            self.alpha * self.corner1[1] + (1 - self.alpha) * self.corner2[1]]

    def when_hit(self):
        self.hit_timer = random.uniform(0.5, 1)

    def update(self, dt):
        MovingPattern.update(self, dt)

        if self.hit_timer > 0:
            self.hit_timer -= dt
            if self.hit_timer <= 0:
                self.hit_timer = 0

        self.alpha -= self.speed * dt
        if self.alpha <= 0:
            self.alpha = 0
            self.speed = -self.speed
            self.current_speed = self.speed
        if self.alpha >= 1:
            self.alpha = 1
            self.speed = -self.speed
            self.current_speed = self.speed

        self.update_current_pos()
        self.enemy.pos = self.current_pos


class MovingPatternCircularContinuous(MovingPattern):

    def __init__(self, enemy, speed=1):
        MovingPattern.__init__(self, enemy)
        self.speed = speed
        self.current_speed = self.speed
        self.center = CENTER
        self.angle = math.pi / 2
        self.radius = 100

        self.hit_timer = 0

    def update_current_pos(self):
        self.current_pos = [self.center[0] + self.radius * math.sin(self.angle),
                            self.center[1] + self.radius * math.cos(self.angle)]

    def spawn(self):
        self.update_current_pos()
        return self.current_pos

    def when_hit(self):
        self.current_speed = self.speed * 5
        self.hit_timer = random.uniform(0.5, 1)

    def update(self, dt):
        MovingPattern.update(self, dt)

        if self.hit_timer > 0:
            self.hit_timer -= dt
            if self.hit_timer <= 0:
                self.hit_timer = 0
                self.current_speed = self.speed 

        self.angle += self.current_speed * dt
        if self.angle >= 2 * math.pi:
            self.angle -= 2 * math.pi
        self.update_current_pos()
        self.enemy.pos = self.current_pos


class MovingPatternCircularContinuousChangingRadius(MovingPatternCircularContinuous):

    def __init__(self, enemy, speed=1, min_radius=20, max_radius=130, radius_speed=10):
        MovingPatternCircularContinuous.__init__(self, enemy, speed)
        self.radius_speed = radius_speed
        self.radius = max_radius
        self.closing_in = True
        self.min_radius = min_radius
        self.max_radius = max_radius

    def update(self, dt):
        if self.closing_in:
            self.radius -= self.radius_speed * dt
        else:
            self.radius += self.radius_speed * dt
        if self.radius <= self.min_radius:
            self.closing_in = False
        if self.radius >= self.max_radius:
            self.closing_in = True
        MovingPatternCircularContinuous.update(self, dt)
