import sys
import math
import itertools
import collections
import random
import pygame
import ptext

import data
import const
import pattern
import curse
import util

class GameWindow(object):
    
    def __init__(self, fullscreen=False):
        pygame.display.set_caption('A Knight of Curses')
        # self.screen = pygame.display.set_mode((const.WIDTH, const.HEIGHT), pygame.FULLSCREEN)
        # pygame.mouse.set_visible(0)
        self.screen = pygame.display.set_mode((const.WIDTH, const.HEIGHT))
        try:
            pygame.mixer.init()
            pygame.mixer.music.load(data.filepath("ClashDefiant.ogg"))
            pygame.mixer.music.play(-1)
            pygame.mixer.music.set_volume(0.1)
        except:
            print 'Cannot load sound. :('
        self.game()
    
    def game(self):
        restart = True
        while restart:
            game = Game(self, self.screen)
            restart = game.loop()        


class Game(object):

    def __init__(self, window, screen):
        self.window = window
        self.real_screen = screen
        self.screen = pygame.surface.Surface((const.REAL_WIDTH, const.REAL_HEIGHT))
        self.clock = pygame.time.Clock()

        self.paused = False

        initial_pos = (const.REAL_WIDTH / 2 - 16, 40)
        self.lives = LifeManager()
        self.character = Character(initial_pos, self.lives)
        self.character_con = pygame.sprite.RenderUpdates(self.character)
        self.bullets = BulletManager(self.character)
        self.enemies = EnemyManager(self.bullets, self.character)

        self.traps = curse.TrapManager()
        self.thoughts = curse.CompulsiveThoughtManager(self.character)
        self.minions = curse.MinionManager()
        self.minion_hives = curse.MinionHiveManager(self.minions)
        self.magnet_circle = curse.BulletMagnetCircle(self.character)
        self.magnet_circle_con = pygame.sprite.RenderUpdates(self.magnet_circle)
        self.sword = curse.Sword(self.character)
        self.sword_con = pygame.sprite.RenderUpdates(self.sword)
        self.curses = curse.CurseManager(self.traps, self.thoughts, self.minion_hives, self.magnet_circle, self.sword, self.damage_pedestal)

        self.pedestal = Pedestal(self.enemies, (const.CENTER[0], const.CENTER[1] - 8), self.start_enemies)
        self.pedestal_con = pygame.sprite.RenderUpdates(self.pedestal)

        self.status_icons = StatusIcons(self.character)
        self.textlayer = TextLayer()
        self.titlelayer = TitleLayer()
        self.titlelayer_con = pygame.sprite.RenderUpdates(self.titlelayer)

        self.collision = CollisionManager()

        self.fullscreen = False
        self.just_changed_fullscreen = False

        self.started = False
        self.started_game_once = False

        self.lost = False
        self.won = False
        self.restart = False

        self.nrun = 1

    def loop(self):
        self.bg = pygame.image.load(data.filepath('bg.png')).convert_alpha()
        self.screen.blit(self.bg, (0, 0))

        pygame.transform.scale(self.screen, (const.WIDTH, const.HEIGHT), self.real_screen)
        pygame.display.update()

        self.done = False

        while not self.done:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    self.on_keydown(event)
                elif event.type == pygame.KEYUP:
                    self.on_keyup(event)

            if not self.paused:
                self.curses.clear(self.screen, self.bg)
                self.traps.clear(self.screen, self.bg)
                self.minion_hives.clear(self.screen, self.bg)
                self.sword_con.clear(self.screen, self.bg)
                self.pedestal_con.clear(self.screen, self.bg)
                self.minions.clear(self.screen, self.bg)
                self.enemies.clear(self.screen, self.bg)
                self.character_con.clear(self.screen, self.bg)
                self.bullets.clear(self.screen, self.bg)
                self.magnet_circle_con.clear(self.screen, self.bg)
                self.thoughts.clear(self.screen, self.bg)
                self.status_icons.clear(self.screen, self.bg)
                self.lives.clear(self.screen, self.bg)
                self.textlayer.clear(self.screen, self.bg)
                self.titlelayer_con.clear(self.screen, self.bg)

            dt = self.clock.tick(const.FPS) / 1000.0

            if not self.paused:
                self.curses.update(dt)
                self.traps.update(dt)
                self.minion_hives.update(dt)
                self.sword_con.update(dt)
                self.pedestal_con.update(dt)
                self.minions.update(dt)
                self.enemies.update(dt)
                self.character_con.update(dt)
                self.bullets.update(dt)
                self.magnet_circle_con.update(dt)
                self.thoughts.update(dt)
                self.status_icons.update(dt)
                self.lives.update(dt)
                self.textlayer.update(dt)
                self.titlelayer_con.update(dt)
                self.collision.handle_collisions(self.character, self.enemies, self.bullets, self.traps, self.minions,
                    self.sword, self.pedestal, self.thoughts)

                self.update(dt)

            update_rects = []
            if not self.paused:
                update_rects += self.curses.draw(self.screen)
                update_rects += self.traps.draw(self.screen)
                update_rects += self.minion_hives.draw(self.screen)
                update_rects += self.sword_con.draw(self.screen)
                update_rects += self.pedestal_con.draw(self.screen)
                update_rects += self.minions.draw(self.screen)
                update_rects += self.enemies.draw(self.screen)
                update_rects += self.character_con.draw(self.screen)
                update_rects += self.bullets.draw(self.screen)
                update_rects += self.magnet_circle_con.draw(self.screen)
                update_rects += self.thoughts.draw(self.screen)
                update_rects += self.status_icons.draw(self.screen)
                update_rects += self.lives.draw(self.screen)
                update_rects += self.textlayer.draw(self.screen)
                update_rects += self.titlelayer_con.draw(self.screen)

            scaled_update_rects = [pygame.Rect(2*r.left - 4, 2*r.top - 4, 2*r.width + 8, 2*r.height + 8) for r in update_rects]

            pygame.transform.scale(self.screen, (const.WIDTH, const.HEIGHT), self.real_screen)
            pygame.display.update(scaled_update_rects)

            if self.just_changed_fullscreen:
                pygame.display.flip() # not sure why this is needed
                self.just_changed_fullscreen = False

        return self.restart

    def on_keydown(self, event):
        if event.key == pygame.K_ESCAPE:
            if self.paused:
                sys.exit()
            else:
                self.pause()
        elif event.key == pygame.K_p:
            self.pause()
        elif event.key == pygame.K_UP or event.key == pygame.K_w:
            self.character.move_up()
        elif event.key == pygame.K_DOWN or event.key == pygame.K_s:
            self.character.move_down()
        elif event.key == pygame.K_LEFT or event.key == pygame.K_a:
            self.character.move_left()
        elif event.key == pygame.K_RIGHT or event.key == pygame.K_d:
            self.character.move_right()

    def on_keyup(self, event):
        if event.key == pygame.K_UP or event.key == pygame.K_w:
            self.character.stop_up()
        elif event.key == pygame.K_DOWN or event.key == pygame.K_s:
            self.character.stop_down()
        elif event.key == pygame.K_LEFT or event.key == pygame.K_a:
            self.character.stop_left()
        elif event.key == pygame.K_RIGHT or event.key == pygame.K_d:
            self.character.stop_right()
        elif event.key in [pygame.K_e, pygame.K_z, pygame.K_x, pygame.K_SPACE, pygame.K_j]:
            self.character.swing()
        elif event.key == pygame.K_n:
            pass
        elif event.key == pygame.K_f:
            if not self.fullscreen:
                pygame.display.set_mode((const.WIDTH, const.HEIGHT), pygame.FULLSCREEN)
                pygame.mouse.set_visible(0)
                self.just_changed_fullscreen = True
                self.fullscreen = True
            else:
                pygame.display.set_mode((const.WIDTH, const.HEIGHT))
                self.just_changed_fullscreen = True
                self.fullscreen = False
        elif event.key == pygame.K_r:
            self.done = True
            self.restart = True

    def pause(self):
        self.paused = not self.paused

    def lose(self):
        self.lost = True
        self.textlayer.draw_lose_text()

    def win(self):
        self.won = True
        self.textlayer.draw_win_text()

    def update(self, dt):
        if self.character.dead and not self.lost:
            self.lose()

        if not self.started_game_once:
            if self.character.pos[0] < 160 and self.character.pos[1] < 60:
                self.titlelayer.open_instructions()
            else:
                self.titlelayer.close_instructions()

        if self.enemies.just_killed is not None:
            self.curses.apply_curse(self.enemies.just_killed)
            self.enemies.just_killed = None
            self.minions.kill_all_minions()
            self.minion_hives.pause_spawning()
            self.started = False
            self.bullets.empty()
            self.thoughts.reset()
            self.thoughts.pause()
            self.character.immune = True
            pygame.mixer.music.set_volume(0.02)

    def start_enemies(self):
        if self.won:
            return
        if not self.started_game_once:
            self.titlelayer_con.empty()
            self.started_game_once = True
        if not self.started:
            self.curses.choose_curse()
            self.enemies.spawn(self.nrun)
            self.nrun += 1
            self.minion_hives.resume_spawning()
            self.thoughts.unpause()
            self.started = True
            self.character.immune = False
            pygame.mixer.music.set_volume(0.1)

    def damage_pedestal(self):
        self.lives.restore_full_life()
        self.status_icons.activate_plus_life()
        sound = pygame.mixer.Sound(data.filepath("success.ogg"))
        sound.set_volume(const.SOUND_VOLUME)
        sound.play()
        self.pedestal.damage()
        if self.pedestal.lives == 0 and not self.won:
            self.win()


class Character(pygame.sprite.Sprite):

    def __init__(self, pos, lives):
        pygame.sprite.Sprite.__init__(self)
        self.pos = list(pos)
        self.vel = [0, 0]

        self.image_ss = pygame.image.load(data.filepath('character_ss.png')).convert_alpha()
        self.image_dead = pygame.image.load(data.filepath('character_dead.png')).convert_alpha()
        self.images = util.slice_sprite_sheet(self.image_ss, 72, 72)

        self.bb = pygame.Rect(24 + 8, 24 + 11, 8, 8)
        self.bb_general = pygame.Rect(26, 24, 20, 24)
        self.bb_feet = pygame.Rect(32, 46, 8, 1)

        walk_anim_interval = 0.15
        swing_anim_intervals = [0.15, 0.3]
        self.still_down_image = self.images[0][0]
        self.still_up_image = self.images[1][0]
        self.still_right_image = self.images[2][0]
        self.still_left_image = self.images[3][0]
        self.move_down_image = util.Animation([self.images[0][1], self.images[0][2]], walk_anim_interval)
        self.move_up_image = util.Animation([self.images[1][1], self.images[1][2]], walk_anim_interval)
        self.move_right_image = util.Animation([self.images[2][1], self.images[2][2]], walk_anim_interval)
        self.move_left_image = util.Animation([self.images[3][1], self.images[3][2]], walk_anim_interval)
        self.swing_down_image = util.Animation([self.images[0][3], self.images[0][4]], swing_anim_intervals)
        self.swing_up_image = util.Animation([self.images[1][3], self.images[1][4]], swing_anim_intervals)
        self.swing_right_image = util.Animation([self.images[2][3], self.images[2][4]], swing_anim_intervals)
        self.swing_left_image = util.Animation([self.images[3][3], self.images[3][4]], swing_anim_intervals)
        self.swordless_still_down_image = self.images[0][5]
        self.swordless_still_up_image = self.images[1][5]
        self.swordless_still_right_image = self.images[2][5]
        self.swordless_still_left_image = self.images[3][5]
        self.swordless_move_down_image = util.Animation([self.images[0][6], self.images[0][7]], walk_anim_interval)
        self.swordless_move_up_image = util.Animation([self.images[1][6], self.images[1][7]], walk_anim_interval)
        self.swordless_move_right_image = util.Animation([self.images[2][6], self.images[2][7]], walk_anim_interval)
        self.swordless_move_left_image = util.Animation([self.images[3][6], self.images[3][7]], walk_anim_interval)

        self.still_images = {'d': self.still_down_image, 'u': self.still_up_image, 'r': self.still_right_image, 'l': self.still_left_image}
        self.move_images = {'d': self.move_down_image, 'u': self.move_up_image, 'r': self.move_right_image, 'l': self.move_left_image}
        self.swing_images = {'d': self.swing_down_image, 'u': self.swing_up_image, 'r': self.swing_right_image, 'l': self.swing_left_image}
        self.swordless_still_images = {'d': self.swordless_still_down_image, 'u': self.swordless_still_up_image, 
            'r': self.swordless_still_right_image, 'l': self.swordless_still_left_image}
        self.swordless_move_images = {'d': self.swordless_move_down_image, 'u': self.swordless_move_up_image, 
            'r': self.swordless_move_right_image, 'l': self.swordless_move_left_image}

        self.image = self.still_down_image
        self.rect = self.image.get_rect()
        self.set_rect_pos()
        self.direction = 'd'

        self.empty_image = pygame.surface.Surface((72, 72))
        self.empty_image.set_colorkey((0,0,0))
        self.flicker_timer = 0.2
        self.flickering = False
        self.true_image = self.image

        self.sword_range_box = {
            'd': pygame.rect.Rect(17, 41, 38, 26),
            'u': pygame.rect.Rect(17, 4, 38, 26),
            'l': pygame.rect.Rect(4, 17, 26, 38),
            'r': pygame.rect.Rect(41, 17, 26, 38)
        }

        self.moving_left = False
        self.moving_right = False
        self.moving_up = False
        self.moving_down = False

        self.speed = 120

        self.lives = lives

        self.invul_timer = 0
        self.invul_time = 1

        self.swinging = False
        self.swinging_actual = False

        self.dead = False

        # Curse attributes

        self.slippery = False
        self.slippery_accel = 1000
        self.slippery_decel = 20

        self.bullet_magnet_radius = 0
        self.bullet_magnet_intensity = 0

        self.butterfingers_chance = 0
        self.sword_slip = False
        self.swordless = False

        self.immune = False

    def set_rect_pos(self):
        self.rect.topleft = (self.pos[0] - self.bb_general.x, self.pos[1] - self.bb_general.y)

    def update(self, dt):
        if self.dead:
            return

        try:
            frame = self.image.update(dt)
            if self.swinging:
                if frame == 1:
                    self.swinging_actual = True
                if frame == 0:
                    if random.uniform(0, 1) < self.butterfingers_chance:
                        self.sword_slip = True
                    self.swinging = False
                    self.swinging_actual = False
                    self.set_image(self.still_images[self.direction])
        except AttributeError:
            pass # not animation

        self.update_timers(dt)
        if self.slippery:
            self.update_move_slippery(dt)
        else:
            self.update_move()

        self.pos[0] += self.vel[0] * dt
        self.pos[1] += self.vel[1] * dt
        self.set_rect_pos()

    def move_left(self):  self.moving_left = True
    def stop_left(self):  self.moving_left = False
    def move_right(self): self.moving_right = True
    def stop_right(self): self.moving_right = False
    def move_up(self):    self.moving_up = True
    def stop_up(self):    self.moving_up = False
    def move_down(self):  self.moving_down = True
    def stop_down(self):  self.moving_down = False

    def update_move(self):
        if self.moving_left:
            self.vel[0] = -self.speed
        elif self.moving_right:
            self.vel[0] = self.speed
        else:
            self.vel[0] = 0
        if self.moving_up:
            self.vel[1] = -self.speed
        elif self.moving_down:
            self.vel[1] = self.speed
        else:
            self.vel[1] = 0
        if not self.swinging:
            self.update_direction()
    
    def update_direction(self):
        still = False
        if self.vel[1] > 0:
            self.direction = 'd'
        elif self.vel[1] < 0:
            self.direction = 'u'
        else:
            if self.vel[0] > 0:
                self.direction = 'r'
            elif self.vel[0] < 0:
                self.direction = 'l'
            else:
                still = True

        if still:
            if self.swordless:
                self.set_image(self.swordless_still_images[self.direction])
            else:
                self.set_image(self.still_images[self.direction])
        else:
            if self.swordless:
                self.set_image(self.swordless_move_images[self.direction])
            else:
                self.set_image(self.move_images[self.direction])

    # Turns out slippery movement is too annoying even for a curse
    def update_move_slippery(self, dt):
        if self.moving_left:
            self.vel[0] += -self.slippery_accel * dt
        elif self.moving_right:
            self.vel[0] += self.slippery_accel * dt
        else:
            if self.vel[0] > 0:
                self.vel[0] = max(0, self.vel[0] - self.slippery_decel * dt)
            elif self.vel[0] < 0:
                self.vel[0] = min(0, self.vel[0] + self.slippery_decel * dt)
        self.vel[0] = max(-self.speed, self.vel[0])
        self.vel[0] = min(self.speed, self.vel[0])
        if self.moving_up:
            self.vel[1] += -self.slippery_accel * dt
        elif self.moving_down:
            self.vel[1] += self.slippery_accel * dt
        else:
            if self.vel[1] > 0:
                self.vel[1] = max(0, self.vel[1] - self.slippery_decel * dt)
            elif self.vel[1] < 0:
                self.vel[1] = min(0, self.vel[1] + self.slippery_decel * dt)
        self.vel[1] = max(-self.speed, self.vel[1])
        self.vel[1] = min(self.speed, self.vel[1])

    def update_timers(self, dt):
        self.invul_timer -= dt
        if self.invul_timer <= 0:
            self.invul_timer = 0
            self.flickering = False
            self.image = self.true_image

        if self.invul_timer > 0:
            self.flicker_timer -= dt
            if self.flicker_timer <= 0:
                self.flicker_timer = 0.1
                self.flicker_switch()

    def swing(self):
        if self.swordless: return
        if self.swinging: return
        image = self.set_image(self.swing_images[self.direction])
        image.start()
        self.swinging = True
        sound = pygame.mixer.Sound(data.filepath("swing.ogg"))
        sound.set_volume(const.SOUND_VOLUME)
        sound.play()

    def get_sword_range_box(self):
        if not self.swinging_actual:
            return pygame.rect.Rect(0,0,0,0)
        else:
            r = pygame.rect.Rect(self.sword_range_box[self.direction])
            r.x += self.rect.x
            r.y += self.rect.y
            return r

    def hit(self, source):
        if self.invul_timer == 0 and not self.immune:
            if isinstance(source, Bullet):
                self.lose_life()
            if isinstance(source, curse.Trap):
                self.lose_life()
            if isinstance(source, curse.Minion):
                if not source.dead:
                    self.lose_life()

    def lose_life(self):
        self.lives.lose_life()
        self.invul_timer = self.invul_time
        if self.lives.lives == 0:
            self.die()

    def die(self):
        self.image = self.image_dead
        self.dead = True

    def remove_sword(self):
        self.swordless = True

    def get_sword(self):
        self.swordless = False

    def flicker_switch(self):
        if self.flickering:
            self.flickering = False
            self.image = self.true_image
        else:
            self.flickering = True
            self.true_image = self.image
            self.image = self.empty_image

    def set_image(self, image):
        self.true_image = image
        if not self.flickering:
            self.image = image
            return self.image
        else:
            return self.true_image


class Bullet(pygame.sprite.Sprite):

    def __init__(self, pos, vel, character, blue):
        pygame.sprite.Sprite.__init__(self)
        self.pos = list(pos)
        self.vel = list(vel)

        self.character = character
        if not blue:
            self.image = pygame.image.load(data.filepath('bullet_red.png')).convert_alpha()
        else:
            self.image = pygame.image.load(data.filepath('bullet_blue.png')).convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.center = self.pos
        self.bb = pygame.Rect(2, 2, 12, 12)

        self.done = False

    def update(self, dt):
        if self.character.bullet_magnet_radius > 0:
            if util.distance(self.character.pos, self.pos) <= self.character.bullet_magnet_radius:
                self.attract_to(self.character.pos, self.character.bullet_magnet_intensity)

        self.pos[0] += self.vel[0] * dt
        self.pos[1] += self.vel[1] * dt
        self.rect.center = [round(self.pos[0]), round(self.pos[1])]

        if self.pos[0] < 20 or self.pos[0] > const.REAL_WIDTH + 20 or self.pos[1] < 20 or self.pos[1] > const.REAL_HEIGHT + 20:
            self.done = True

    def attract_to(self, target, intensity):
        to_target = util.get_normalized_vector(self.pos, target)
        current_speed = math.hypot(self.vel[0], self.vel[1])
        self.vel[0] -= intensity * to_target[0]
        self.vel[1] -= intensity * to_target[1]
        norm = math.hypot(self.vel[0], self.vel[1]) # leave speed unchanged
        self.vel[0] = self.vel[0] * current_speed / norm
        self.vel[1] = self.vel[1] * current_speed / norm

    def hit(self, source):
        if isinstance(source, Character):
            if source.invul_timer == 0:
                self.done = True


class BulletManager(pygame.sprite.RenderUpdates):

    def __init__(self, character):
        pygame.sprite.RenderUpdates.__init__(self)
        self.character = character

    def create(self, origin, vel, blue):
        bullet = Bullet(origin, vel, self.character, blue)
        self.add(bullet)

    def update(self, dt):
        pygame.sprite.RenderUpdates.update(self, dt)
        bullets_done = [bullet for bullet in self if bullet.done]
        for bullet in bullets_done:
            self.remove(bullet)


class Enemy(pygame.sprite.Sprite):

    def __init__(self, pos, bullets, character, nrun, following=None):
        pygame.sprite.Sprite.__init__(self)
        self.pos = list(pos)
        self.vel = [0, 0]

        self.following = following # duplicates movement of other enemy

        if self.following:
            self.image_idle = pygame.image.load(data.filepath('enemy_blue.png')).convert_alpha()
            self.image_attack = pygame.image.load(data.filepath('enemy_blue_attack.png')).convert_alpha()
        else:
            self.image_idle = pygame.image.load(data.filepath('enemy_red.png')).convert_alpha()
            self.image_attack = pygame.image.load(data.filepath('enemy_red_attack.png')).convert_alpha()
        self.image = self.image_idle
        self.rect = self.image.get_rect()
        self.bb = pygame.Rect(8, 0, 48, 60)

        # Difficulty tier
        self.tier = pattern.get_tier(nrun)
        time_between_shots = pattern.TIME_BETWEEN_SHOTS[self.tier]
        number_of_shots = pattern.NUMBER_OF_SHOTS[self.tier]
        shot_type = random.choice(pattern.SHOT_TYPES[self.tier])

        self.firing_pattern = pattern.FiringPatternSuccessiveLock(bullets, 100, self, character, number_of_shots, shot_type)
        self.timing_pattern = pattern.TimingPatternSuccessiveThenWait(time_between_shots, 0.2, number_of_shots)

        self.moving_pattern = random.choice([pattern.MovingPatternCornersWhenHit(self), pattern.MovingPatternCircularContinuous(self),
            pattern.MovingPatternCircularContinuousChangingRadius(self), pattern.MovingPatternBetweenCornersContinuous(self, self.tier)])

        if self.following:
            self.mirror_following()
        else:            
            self.pos = list(self.moving_pattern.spawn())
        self.rect.center = self.pos

        self.life = 3

        self.invul_timer = 0

        self.done = False

        self.empty_image = pygame.surface.Surface((64, 64))
        self.empty_image.set_colorkey((0,0,0))
        self.flicker_timer = 0.2
        self.flickering = False
        self.true_image = self.image

    def mirror_following(self):
        if self.following:
            self.pos = [const.REAL_WIDTH - self.following.pos[0], const.REAL_HEIGHT - self.following.pos[1]]

    def hit_rect(self, collision_type):
        if collision_type == 'sword':
            if self.invul_timer <= 0:
                self.lose_life()
                sound = pygame.mixer.Sound(data.filepath("hit.ogg"))
                sound.set_volume(const.SOUND_VOLUME)
                sound.play()

    def lose_life(self):
        self.life -= 1
        if self.life <= 0:
            self.die()
        else:
            if self.following:
                self.following.moving_pattern.when_hit()
            else:
                self.moving_pattern.when_hit()
            self.invul_timer = 1

    def die(self):
        self.done = True

    def update(self, dt):
        if not self.following:
            self.moving_pattern.update(dt)
        else:
            self.mirror_following()

        if self.invul_timer > 0:
            self.invul_timer -= dt
            if self.invul_timer <= 0:
                self.invul_timer = 0
                self.flickering = False
                self.image = self.true_image
            else:
                self.flicker_timer -= dt
                if self.flicker_timer <= 0:
                    self.flicker_timer = 0.1
                    self.flicker_switch()

        self.rect.center = self.pos

        # if self.invul_timer <= 0: # do not shoot if just been hit
        if self.timing_pattern.update_fire_now(dt):
            self.firing_pattern.fire()

        if self.timing_pattern.attacking:
            self.set_image(self.image_attack)
        else:
            self.set_image(self.image_idle)

    def flicker_switch(self):
        if self.flickering:
            self.flickering = False
            self.image = self.true_image
        else:
            self.flickering = True
            self.true_image = self.image
            self.image = self.empty_image

    def set_image(self, image):
        self.true_image = image
        if not self.flickering:
            self.image = image
            return self.image
        else:
            return self.true_image


class EnemyManager(pygame.sprite.RenderUpdates):

    def __init__(self, bullets, character):
        pygame.sprite.RenderUpdates.__init__(self)
        self.bullets = bullets
        self.character = character
        self.active = False
        self.just_killed = None
        self.enemy_red = None
        self.enemy_blue = None

    def spawn(self, nrun):
        self.active = True
        self.enemy_red = Enemy((100, 100), self.bullets, self.character, nrun)
        self.enemy_blue = Enemy((100, 100), self.bullets, self.character, nrun, self.enemy_red)
        self.add(self.enemy_red)
        self.add(self.enemy_blue)

    def update(self, dt):
        pygame.sprite.RenderUpdates.update(self, dt)
        if self.enemy_red is not None and self.enemy_blue is not None:
            if self.enemy_red.done or self.enemy_blue.done:
                self.empty()
                self.active = False
                if self.enemy_red.done:
                    self.just_killed = 'red'
                elif self.enemy_blue.done:
                    self.just_killed = 'blue'
                self.enemy_red = None
                self.enemy_blue = None


class CollisionManager(object):

    def handle_collisions(self, character, enemies, bullets, traps, minions, sword, pedestal, thoughts):
        self.handle_wall_character_collision(character, thoughts)
        for enemy in enemies:
            self.handle_bb_collision(character, enemy)
            self.handle_rect_collision(character.get_sword_range_box(), enemy, 'sword')
        for bullet in bullets:
            self.handle_bb_collision(bullet, character) # order matters, unfortunately
        for trap in traps:
            self.handle_bb_collision(character, trap, sprite1_bb=character.bb_feet)
        for minion in minions:
            self.handle_bb_collision(character, minion, sprite1_bb=character.bb_feet)
            self.handle_rect_collision(character.get_sword_range_box(), minion, 'sword')
            self.handle_bb_collision(minion, sword)
        self.handle_bb_collision(character, sword)
        self.handle_rect_collision(character.get_sword_range_box(), pedestal, 'sword')

    def handle_wall_character_collision(self, character, thoughts):
        r = util.get_bb_rect(character.rect, character.bb_general)
        if r.x < const.WALL_THICKNESS:
            r.x = const.WALL_THICKNESS
            character.pos[0] = r.x
            thoughts.touched_wall('l')
        if r.x + r.width >= const.REAL_WIDTH - const.WALL_THICKNESS:
            r.x = const.REAL_WIDTH - const.WALL_THICKNESS - r.width
            character.pos[0] = r.x
            thoughts.touched_wall('r')
        if r.y < const.WALL_THICKNESS:
            r.y = const.WALL_THICKNESS
            character.pos[1] = r.y
            thoughts.touched_wall('t')
        if r.y + r.height >= const.REAL_HEIGHT - const.WALL_THICKNESS:
            r.y = const.REAL_HEIGHT - const.WALL_THICKNESS - r.height
            character.pos[1] = r.y
            thoughts.touched_wall('b')
        character.set_rect_pos()

    def handle_bb_collision(self, sprite1, sprite2, sprite1_bb=None, sprite2_bb=None):
        if sprite1_bb == None:
            try:
                sprite1_bb = sprite1.bb
            except AttributeError: # no bounding box; use entire rect
                sprite1_bb = pygame.Rect(0, 0, sprite1.rect.width, sprite1.rect.height)
        if sprite2_bb == None:
            try:
                sprite2_bb = sprite2.bb
            except AttributeError: # no bounding box; use entire rect
                sprite2_bb = pygame.Rect(0, 0, sprite2.rect.width, sprite2.rect.height)
        
        sprite1_rect = pygame.Rect(sprite1.rect.x + sprite1_bb.x, sprite1.rect.y + sprite1_bb.y, sprite1_bb.width, sprite1_bb.height)
        sprite2_rect = pygame.Rect(sprite2.rect.x + sprite2_bb.x, sprite2.rect.y + sprite2_bb.y, sprite2_bb.width, sprite2_bb.height)

        if sprite1_rect.colliderect(sprite2_rect):
            try:
                sprite1.hit(sprite2)
            except AttributeError: # no hit; ignore
                pass
            try:
                sprite2.hit(sprite1)
            except AttributeError: # no hit; ignore
                pass

    def handle_rect_collision(self, rect, sprite, collision_type):
        try:
            sprite_bb = pygame.Rect(sprite.rect.x + sprite.bb.x, sprite.rect.y + sprite.bb.y, sprite.bb.width, sprite.bb.height)
        except AttributeError: # no bounding box; use rect
            sprite_bb = pygame.Rect(sprite.rect.x, sprite.rect.y, sprite.rect.width, sprite.rect.height)
        if rect.colliderect(sprite_bb):
            try:
                sprite.hit_rect(collision_type)
            except AttributeError: # no hit; ignore
                pass


class Pedestal(pygame.sprite.Sprite):

    def __init__(self, enemies, pos, start_func):
        pygame.sprite.Sprite.__init__(self)
        self.enemies = enemies
        self.start_func = start_func
        self.pos = list(pos)

        self.image_ss = pygame.image.load(data.filepath('pedestal.png')).convert_alpha()
        self.images = util.slice_sprite_sheet(self.image_ss, 12, 22)
        self.image_full = util.Animation([self.images[0][0], self.images[0][1], self.images[0][2], self.images[0][3]], 0.1)
        self.image_onehit = util.Animation([self.images[1][0], self.images[1][1], self.images[1][2], self.images[1][3]], 0.1)
        self.image_twohits = util.Animation([self.images[2][0], self.images[2][1], self.images[2][2], self.images[2][3]], 0.1)
        self.image_threehits = util.Animation([self.images[3][0], self.images[3][1], self.images[3][2], self.images[3][3]], 0.1)
        self.image_destroy = util.Animation([self.images[4][0], self.images[4][1], self.images[4][2]], [0.4, 0.4, 100000])
        # self.images_by_life = [self.image_destroy, self.image_threehits, self.image_twohits, self.image_onehit, self.image_full]
        self.images_by_life = [self.image_destroy, self.image_twohits, self.image_onehit, self.image_full]

        self.image = self.image_full
        self.image.start()

        self.lives = 3

        self.rect = self.image.get_rect()
        self.rect.center = self.pos

    def hit_rect(self, collision_type):
        if self.enemies.active:
            return
        if collision_type == 'sword':
            self.start_func()
            sound = pygame.mixer.Sound(data.filepath("pedestal_hit.ogg"))
            sound.set_volume(const.SOUND_VOLUME)
            sound.play()

    def damage(self):
        self.lives -= 1
        self.image = self.images_by_life[self.lives]
        self.image.start()

    def update(self, dt):
        self.image.update(dt)


class Life(pygame.sprite.Sprite):

    def __init__(self, pos):
        pygame.sprite.Sprite.__init__(self)
        self.pos = list(pos)

        self.image_full = pygame.image.load(data.filepath('heart_filled.png')).convert_alpha()
        self.image_empty = pygame.image.load(data.filepath('heart_empty.png')).convert_alpha()

        self.image = self.image_full
        self.rect = self.image.get_rect()
        self.rect.topleft = self.pos

    def turn_on(self):
        self.image = self.image_full

    def turn_off(self):
        self.image = self.image_empty


class LifeManager(pygame.sprite.RenderUpdates):

    def __init__(self):
        pygame.sprite.RenderUpdates.__init__(self)
        self.life_sprites = []
        self.max_lives = 3
        self.lives = self.max_lives

        for i in range(self.max_lives):
            life = Life((1, 2 + i * 17))
            life.turn_on()
            self.life_sprites.append(life)
            self.add(life)

    def update_lives(self):
        for i in range(self.max_lives):
            self.life_sprites[i].turn_off()
        for i in range(self.lives):
            self.life_sprites[i].turn_on()

    def lose_life(self):
        if self.lives > 0:
            self.lives -= 1
            self.update_lives()
            sound = pygame.mixer.Sound(data.filepath("player_hit.ogg"))
            sound.set_volume(const.SOUND_VOLUME)
            sound.play()

    def gain_life(self):
        if self.lives < self.max_lives:
            self.lives += 1
            self.update_lives()

    def restore_full_life(self):
        self.lives = self.max_lives
        self.update_lives()


class StatusIcons(pygame.sprite.RenderUpdates):

    def __init__(self, character):
        pygame.sprite.RenderUpdates.__init__(self)
        self.character = character
        self.plus_life_image = pygame.image.load(data.filepath('plus_life_icon.png')).convert_alpha()
        self.plus_life = pygame.sprite.Sprite()
        self.plus_life.image = self.plus_life_image
        self.plus_life.rect = self.plus_life.image.get_rect()
        self.active = False
        self.active_timer = 0

    def activate_plus_life(self):
        self.active_timer = 3
        self.active = True
        self.add(self.plus_life)

    def deactivate(self):
        self.active_timer = 0
        self.active = False
        self.empty()

    def update(self, dt):
        if self.active:
            for sprite in self:
                sprite.rect.center = (self.character.rect.center[0], self.character.rect.center[1] - 16)
            self.active_timer -= dt
            if self.active_timer <= 0:
                self.deactivate()


class TextLayer(pygame.sprite.RenderUpdates):

    def __init__(self):
        pygame.sprite.RenderUpdates.__init__(self)

    def draw_lose_text(self):
        sprite = pygame.sprite.Sprite()
        sprite.image, pos = ptext.draw("Press R to restart", (const.REAL_WIDTH / 2, const.REAL_HEIGHT - 3),
            anchor=(0.5,1), color=(255,255,255), fontname=const.FONT_MAIN)
        sprite.rect = sprite.image.get_rect()
        sprite.rect.topleft = pos
        self.add(sprite)

    def draw_win_text(self):
        sprite = pygame.sprite.Sprite()
        sprite.image, pos = ptext.draw("You defeated the spirits!\n Congratulations!", (const.REAL_WIDTH / 2, const.REAL_HEIGHT / 2 - 50),
            anchor=(0.5,1), color=(255,255,255), fontname=const.FONT_MAIN, fontsize=20)
        sprite.rect = sprite.image.get_rect()
        sprite.rect.topleft = pos
        self.add(sprite)


class TitleLayer(pygame.sprite.Sprite):

    def __init__(self):
        pygame.sprite.Sprite.__init__(self)

        self.title_image = pygame.image.load(data.filepath("title.png")).convert_alpha()
        self.inst_image = pygame.image.load(data.filepath("instructions.png")).convert_alpha()
        self.image = self.title_image
        self.rect = self.image.get_rect()
        self.rect.topleft = (0, 0)

    def open_instructions(self):
        self.image = self.inst_image
        self.rect = self.image.get_rect()
        self.rect.topleft = (0, 0)

    def close_instructions(self):
        self.image = self.title_image
        self.rect = self.image.get_rect()
        self.rect.topleft = (0, 0)



if __name__ == '__main__':
    try:
        pygame.mixer.pre_init(44100, -16, 1, 512)
    except:
        pass
    pygame.init()
    GameWindow()