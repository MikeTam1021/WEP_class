import math
import random
import pygame

import data
import const
import util


class CurseManager(pygame.sprite.RenderUpdates):

    def __init__(self, traps, thoughts, minion_hives, magnet_circle, sword, damage_func):
        pygame.sprite.RenderUpdates.__init__(self)
        self.curses = []
        self.curses.append(CurseCompulsiveWallTouching(thoughts))
        self.curses.append(CurseTraps(traps))
        self.curses.append(CurseMinions(minion_hives))
        self.curses.append(CurseBulletMagnet(magnet_circle))
        self.curses.append(CurseButterfingers(sword))

        self.curse_red = 0
        self.curse_blue = 0

        self.add(CurseIcons())
        ncurses = len(self.curses)

        self.indicators = [CurseIndicator(i) for i in range(ncurses)]
        for indicator in self.indicators:
            self.add(indicator)

        self.damage_func = damage_func    

    def choose_curse(self):
        self.curse_red, self.curse_blue = random.sample(range(len(self.curses)), 2)
        self.indicators[self.curse_red].set_level_red(self.curses[self.curse_red].level)
        self.indicators[self.curse_blue].set_level_blue(self.curses[self.curse_blue].level)

    def apply_curse(self, color):
        if color == 'red':
            self.activate_curse(self.curse_red)
        elif color == 'blue':
            self.activate_curse(self.curse_blue)

    def update_all_indicators(self):
        for i, indicator in enumerate(self.indicators):
            indicator.set_level(self.curses[i].level)

    def check_full_curse(self):
        all_curses_on = True
        for curse in self.curses:
            if curse.level == 0:
                all_curses_on = False

        if all_curses_on:
            for curse in self.curses:
                curse.prev_level()
            return True

        return False

    def activate_curse(self, curse_idx):
        reset = self.curses[curse_idx].next_level()
        if reset or self.check_full_curse():
            self.damage_func()
        self.update_all_indicators()


class CurseIcons(pygame.sprite.Sprite):

    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(data.filepath('curse_icons.png')).convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.center = const.CENTER


class CurseIndicator(pygame.sprite.Sprite):

    def __init__(self, idx):
        pygame.sprite.Sprite.__init__(self)
        self.idx = idx
        self.image_ss = pygame.image.load(data.filepath('curse_indicators.png')).convert_alpha()
        self.images = util.slice_sprite_sheet(self.image_ss, 96, 96)
        self.image = self.images[idx][0]
        self.rect = self.image.get_rect()
        self.rect.center = const.CENTER

    def set_level(self, level):
        self.image = self.images[self.idx][3 * level]
        self.rect = self.image.get_rect()
        self.rect.center = const.CENTER

    def set_level_red(self, level):
        self.image = self.images[self.idx][3 * level + 1]
        self.rect = self.image.get_rect()
        self.rect.center = const.CENTER

    def set_level_blue(self, level):
        self.image = self.images[self.idx][3 * level + 2]
        self.rect = self.image.get_rect()
        self.rect.center = const.CENTER


class Curse(object):

    def __init__(self, name):
        self.level = 0
        self.name = name

    def next_level(self): # return True if reset
        self.level += 1
        if self.level >= 4:
            self.level = 0
            return True
        return False

    def prev_level(self):
        if self.level > 0:
            self.level -= 1


class CurseCompulsiveWallTouching(Curse):

    def __init__(self, thoughts):
        Curse.__init__(self, 'cwt')
        self.thoughts = thoughts

    def next_level(self):
        reset = Curse.next_level(self)
        self.thoughts.set_level(self.level)
        return reset

    def prev_level(self):
        Curse.prev_level(self)
        self.thoughts.set_level(self.level)


class CurseTraps(Curse):

    def __init__(self, traps):
        Curse.__init__(self, 'traps')
        self.traps = traps

    def next_level(self):
        reset = Curse.next_level(self)
        if not reset:
            self.traps.add_traps(self.level)
        else:
            self.traps.clear_traps()
        return reset

    def prev_level(self):
        Curse.prev_level(self)
        self.traps.clear_traps()
        for i in range(1, self.level - 1):
            self.traps.add_traps(i) # hackish, not enough time


class CurseMinions(Curse):

    def __init__(self, minion_hives):
        Curse.__init__(self, 'minions')
        self.minion_hives = minion_hives

    def next_level(self):
        reset = Curse.next_level(self)
        if not reset:
            self.minion_hives.add_hive()
            if self.level == 3:
                self.minion_hives.add_hive()
        else:
            self.minion_hives.clear_hives()
        return reset

    def prev_level(self):
        Curse.prev_level(self)
        self.minion_hives.clear_hives()
        if self.level == 1: # hackish, not enough time
            self.minion_hives.add_hive()
        elif self.level == 2:
            self.minion_hives.add_hive()


class CurseBulletMagnet(Curse):

    RADIUS = [0, 40, 50, 80]
    INTENSITY = [0, 3, 5, 6]

    def __init__(self, magnet_circle):
        Curse.__init__(self, 'magnet')
        self.magnet_circle = magnet_circle

    def next_level(self):
        reset = Curse.next_level(self)
        self.magnet_circle.update_radius(self.RADIUS[self.level], self.INTENSITY[self.level])
        return reset

    def prev_level(self):
        Curse.prev_level(self)
        self.magnet_circle.update_radius(self.RADIUS[self.level], self.INTENSITY[self.level])


class CurseButterfingers(Curse):

    def __init__(self, sword):
        Curse.__init__(self, 'butterfingers')
        self.sword = sword

    def next_level(self):
        reset = Curse.next_level(self)
        self.sword.set_level(self.level)
        return reset

    def prev_level(self):
        Curse.prev_level(self)
        self.sword.set_level(self.level)


class Trap(pygame.sprite.Sprite):

    def __init__(self, pos):
        pygame.sprite.Sprite.__init__(self)
        self.pos = list(pos)

        self.image = pygame.image.load(data.filepath('trap.png')).convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.center = self.pos
        self.bb = pygame.rect.Rect((1,1,23,24))


class TrapManager(pygame.sprite.RenderUpdates):

    TRAP_LOCATIONS = [ # These are automatically mirrored below
        [],
        [(48, 48)],  # Level 1
        [(96, 96)],  # Level 2
        [(144, 48), (48, 144)]   # Level 3
    ]

    def __init__(self):
        pygame.sprite.RenderUpdates.__init__(self)

    def clear_traps(self):
        self.empty()

    def add_traps(self, level):
        for loc in self.TRAP_LOCATIONS[level]:
            # Extra y is to account for wall
            trap = Trap((loc[0], loc[1] + 16))
            self.add(trap)
            trap = Trap((const.REAL_WIDTH - loc[0], loc[1] + 16))
            self.add(trap)
            trap = Trap((loc[0], const.REAL_HEIGHT - loc[1]))
            self.add(trap)
            trap = Trap((const.REAL_WIDTH - loc[0], const.REAL_HEIGHT - loc[1]))
            self.add(trap)


class Minion(pygame.sprite.Sprite):

    def __init__(self, pos):
        pygame.sprite.Sprite.__init__(self)
        self.pos = list(pos)

        self.image_ss = pygame.image.load(data.filepath('minion.png')).convert_alpha()
        self.images = util.slice_sprite_sheet(self.image_ss, 12, 12)

        walk_anim_speed = 0.15
        self.image_stop_se = self.images[0][0]
        self.image_stop_sw = self.images[0][2]
        self.image_stop_ne = self.images[1][0]
        self.image_stop_nw = self.images[1][2]
        self.image_walk_se = util.Animation([self.images[0][0], self.images[0][1]], walk_anim_speed)
        self.image_walk_sw = util.Animation([self.images[0][2], self.images[0][3]], walk_anim_speed)
        self.image_walk_ne = util.Animation([self.images[1][0], self.images[1][1]], walk_anim_speed)
        self.image_walk_nw = util.Animation([self.images[1][2], self.images[1][3]], walk_anim_speed)
        self.image_dead = self.images[0][4]

        self.image_stop = {'se': self.image_stop_se, 'sw': self.image_stop_sw, 'ne': self.image_stop_ne, 'nw': self.image_stop_nw}
        self.image_walk = {'se': self.image_walk_se, 'sw': self.image_walk_sw, 'ne': self.image_walk_ne, 'nw': self.image_walk_nw}

        self.image = self.image_stop_se
        self.rect = self.image.get_rect()
        self.rect.center = self.pos
        self.bb = pygame.rect.Rect(2, 2, 8, 8)

        self.speed = 50
        self.dirs = {'se': [self.speed, self.speed], 'sw': [-self.speed, self.speed], 'ne': [self.speed, -self.speed], 'nw': [-self.speed, -self.speed]}
        self.choose_random_direction()
        self.stop_time = 0

        self.dead = False
        self.done = False

    def choose_random_direction(self):
        self.direction = random.choice(self.dirs.keys())
        self.vel = list(self.dirs[self.direction])
        self.walk_time = random.uniform(2, 5)
        self.start_walk_anim()
        self.walking = True

    def start_walk_anim(self):
        self.image = self.image_walk[self.direction]
        self.image.start()

    def stop_walking(self):
        self.walking = False
        self.image = self.image_stop[self.direction]
        self.stop_time = random.uniform(1, 3)
        self.vel = [0, 0]

    def hit_rect(self, collision_type):
        if collision_type == 'sword':
            if not self.dead:
                self.die()
                sound = pygame.mixer.Sound(data.filepath("hit.ogg"))
                sound.set_volume(const.SOUND_VOLUME)
                sound.play()

    def hit(self, source):
        if isinstance(source, Sword):
            if math.hypot(source.vel[0], source.vel[1]) > 10:
                self.die()

    def die(self):
        self.image = self.image_dead
        self.vel = [0, 0]
        self.dead_time = 1.5
        self.dead = True

    def update_wall_collision(self, dt):
        if self.rect.x < const.WALL_THICKNESS:
            self.rect.x = const.WALL_THICKNESS + 1
            self.pos[0] = self.rect.centerx
            self.vel[0] = -self.vel[0]
            self.direction = self.direction[0] + 'e'
            self.start_walk_anim()
        if self.rect.x + self.rect.width >= const.REAL_WIDTH - const.WALL_THICKNESS:
            self.rect.x = const.REAL_WIDTH - const.WALL_THICKNESS - self.rect.width - 1
            self.pos[0] = self.rect.centerx
            self.vel[0] = -self.vel[0]
            self.direction = self.direction[0] + 'w'
            self.start_walk_anim()
        if self.rect.y < const.WALL_THICKNESS + 10:
            self.rect.y = const.WALL_THICKNESS + 10 + 1
            self.pos[1] = self.rect.centery
            self.vel[1] = -self.vel[1]
            self.direction = 's' + self.direction[1]
            self.start_walk_anim()
        if self.rect.y + self.rect.height >= const.REAL_HEIGHT - const.WALL_THICKNESS:
            self.rect.y = const.REAL_HEIGHT - const.WALL_THICKNESS - self.rect.height - 1
            self.pos[1] = self.rect.centery
            self.vel[1] = -self.vel[1]
            self.direction = 'n' + self.direction[1]
            self.start_walk_anim()

    def update(self, dt):
        try:
            self.image.update(dt)
        except AttributeError: pass

        if self.dead:
            self.dead_time -= dt
            if self.dead_time <= 0:
                self.done = True
            return

        if self.walking:
            self.walk_time -= dt
            if self.walk_time <= 0:
                self.walk_time = 0
                self.stop_walking()
        else:
            self.stop_time -= dt
            if self.stop_time <= 0:
                self.stop_time = 0
                self.choose_random_direction()

        self.pos[0] += self.vel[0] * dt
        self.pos[1] += self.vel[1] * dt
        self.update_wall_collision(dt)
        self.rect.center = self.pos


class MinionManager(pygame.sprite.RenderUpdates):

    def __init__(self):
        pygame.sprite.RenderUpdates.__init__(self)

    def spawn(self, pos):
        minion = Minion(pos)
        self.add(minion)

    def update(self, dt):
        pygame.sprite.RenderUpdates.update(self, dt)
        done_minions = [minion for minion in self if minion.done]
        for minion in done_minions:
            self.remove(minion)

    def kill_all_minions(self):
        for minion in self:
            minion.die()


class MinionHive(pygame.sprite.Sprite):

    def __init__(self, minions, pos, min_spawn_interval, max_spawn_interval):
        pygame.sprite.Sprite.__init__(self)
        self.pos = list(pos)

        self.image_ss = pygame.image.load(data.filepath('minion_hive.png')).convert_alpha()
        self.images = util.slice_sprite_sheet(self.image_ss, 26, 18)

        self.image_idle = self.images[0][0]
        self.image_spawning = util.Animation([self.images[1][0], self.images[2][0]], 0.5)

        self.image = self.image_idle
        self.rect = self.image.get_rect()
        self.rect.center = self.pos

        self.spawning = False

        self.max_spawn_interval = max_spawn_interval
        self.min_spawn_interval = min_spawn_interval
        self.wait_timer = random.uniform(self.min_spawn_interval, self.max_spawn_interval)

        self.minions = minions

        self.paused = False

    def start_spawn(self):
        self.image = self.image_spawning
        self.image.start()
        self.spawning = True

    def spawn(self):
        self.wait_timer = random.uniform(self.min_spawn_interval, self.max_spawn_interval)
        self.minions.spawn((self.pos[0], self.pos[1] + 7))

    def pause_spawning(self):
        self.paused = True
        self.image = self.image_idle
        self.spawning = False

    def resume_spawning(self):
        self.paused = False
        self.wait_timer = random.uniform(self.min_spawn_interval, self.max_spawn_interval)

    def update(self, dt):
        if self.paused:
            return

        if not self.spawning:
            self.wait_timer -= dt
            if self.wait_timer <= 0:
                self.start_spawn()
                self.wait_timer = 0
        else:
            frame = self.image.update(dt)
            if frame == 0:
                self.spawning = False
                self.image = self.image_idle
                self.spawn()


class MinionHiveManager(pygame.sprite.RenderUpdates):

    POSSIBLE_POS = [(96, 56), (288, 56), (96, 340), (288, 340), (126, 192), (258, 192), (192, 106), (192, 278)]

    def __init__(self, minions):
        pygame.sprite.RenderUpdates.__init__(self)
        self.minions = minions
        self.available_pos = list(self.POSSIBLE_POS)

    def clear_hives(self):
        self.empty()
        self.available_pos = list(self.POSSIBLE_POS)

    def add_hive(self):
        if len(self.available_pos) > 0:
            pos = random.choice(self.available_pos)
            hive = MinionHive(self.minions, pos, 2, 4)
            self.add(hive)
            self.available_pos.remove(pos)

    def pause_spawning(self):
        for hive in self:
            hive.pause_spawning()

    def resume_spawning(self):
        for hive in self:
            hive.resume_spawning()


class CompulsiveThought(pygame.sprite.Sprite):

    def __init__(self, character, radius, speed, perturbation, direction, first_text):
        pygame.sprite.Sprite.__init__(self)
        self.character = character
        self.radius = radius
        self.speed = speed
        self.perturbation = perturbation
        self.angle = random.uniform(0, 2* math.pi)
        self.update_current_pos()

        if first_text:
            if direction == None:
                filename = 'cwt1.png'
            else:
                filename = 'cwt1_' + direction + '.png'
        else:
            if direction == None:
                filename = random.choice(['cwt1.png', 'cwt2.png', 'cwt3.png', 'cwt4.png', 'cwt5.png'])
            else:
                filename = random.choice(['cwt1_' + direction + '.png', 'cwt2.png', 'cwt2_' + direction + '.png', 'cwt4.png', 'cwt5.png'])
        self.image = pygame.image.load(data.filepath(filename)).convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.center = self.pos

    def update_current_pos(self):
        self.pos = [self.character.pos[0] + self.radius * math.sin(self.angle),
                    self.character.pos[1] + self.radius * math.cos(self.angle)]

    def update(self, dt):
        self.update_current_pos()
        self.angle += self.speed * dt
        if self.angle >= 2 * math.pi:
            self.angle -= 2 * math.pi

        # random perturbation
        self.pos[0] += random.uniform(-self.perturbation, self.perturbation)
        self.pos[1] += random.uniform(-self.perturbation, self.perturbation)

        self.rect.center = self.pos


class CompulsiveThoughtManager(pygame.sprite.RenderUpdates):

    LEVEL_MAX_THOUGHTS = [0, 5, 10, 30]
    LEVEL_PERTURBATION = [0, 1, 2, 3]

    def __init__(self, character):
        pygame.sprite.RenderUpdates.__init__(self)
        self.character = character

        self.spawn_intervals = [3, 2, 2, 2, 1, 1, 1, 0.5]
        self.set_level(0)

        self.direction = None
        self.paused = False

    def set_level(self, level):
        self.level = level
        self.update_by_level()

    def update_by_level(self):
        self.max_thoughts = self.LEVEL_MAX_THOUGHTS[self.level]
        self.spawn_timer = self.spawn_intervals[0]
        if self.level == 2 or self.level == 3:
            self.direction = random.choice(['t', 'b', 'l', 'r'])
        else:
            self.direction = None

    def touched_wall(self, wall):
        if self.direction is None or self.direction == wall:
            self.reset()

    def reset(self):
        self.empty()
        self.update_by_level()

    def pause(self):
        self.paused = True

    def unpause(self):
        self.paused = False

    def update(self, dt):
        pygame.sprite.RenderUpdates.update(self, dt)
        if self.paused:
            return
        if self.level > 0:
            self.spawn_timer -= dt
            if self.spawn_timer <= 0:
                nthoughts = len(self.sprites())
                nthoughts += self.level - 1 # minor tweak
                if nthoughts >= len(self.spawn_intervals):
                    nthoughts = -1
                self.spawn_timer = self.spawn_intervals[nthoughts]
                self.spawn()

    def spawn(self):
        if len(self.sprites()) < self.max_thoughts:
            radius = random.randint(10, 100)
            speed = random.choice([random.uniform(-4,-1), random.uniform(1,4)])
            first_text = (len(self.sprites()) == 0)
            thought = CompulsiveThought(self.character, radius, speed, self.LEVEL_PERTURBATION[self.level], self.direction, first_text)
            self.add(thought)


class BulletMagnetCircle(pygame.sprite.Sprite):

    def __init__(self, character):
        pygame.sprite.Sprite.__init__(self)
        self.character = character
        self.update_radius(0, 0)

    def update_radius(self, radius, intensity):
        self.character.bullet_magnet_radius = radius
        self.character.bullet_magnet_intensity = intensity
        self.radius = radius
        self.image = pygame.surface.Surface((radius * 2, radius * 2))
        self.image.set_colorkey((0,0,0))
        if radius > 0:
            pygame.draw.circle(self.image, (200,160,160), (radius, radius), radius, 1)
        self.rect = self.image.get_rect()
        self.rect.center = self.character.rect.center

    def update(self, dt):
        self.rect.center = self.character.rect.center


class Sword(pygame.sprite.Sprite):

    LAUNCH_SPEEDS = [0, 100, 250, 500]
    CHANCES = [0, 0.25, 0.5, 1.0]

    def __init__(self, character):
        pygame.sprite.Sprite.__init__(self)
        self.character = character
        self.friction_coeff = 2

        self.image_empty = pygame.surface.Surface((15, 15))
        self.image_empty.set_colorkey((0,0,0))
        self.image_sword = pygame.image.load(data.filepath('sword.png')).convert_alpha()

        self.image = self.image_empty
        self.rect = self.image.get_rect()
        self.rect.center = (0,0)

        self.vel = [0, 0]

        self.enabled = False
        self.pickable = False
        self.pickable_speed = 40

        self.set_level(0)

    def set_level(self, level):
        self.level = level
        self.launch_speed = self.LAUNCH_SPEEDS[self.level]
        self.character.butterfingers_chance = self.CHANCES[self.level]

    def enable(self):
        self.enabled = True

        self.image = self.image_sword
        self.rect = self.image.get_rect()

        self.vel[0] = random.uniform(-1, 1)
        self.vel[1] = random.uniform(-1, 1)
        while self.vel[0] <= 1e-4 and self.vel[1] <= 1e-4:
            self.vel[0] = random.uniform(-1, 1)
            self.vel[1] = random.uniform(-1, 1)
        norm = math.hypot(self.vel[0], self.vel[1])
        self.vel[0] /= norm
        self.vel[1] /= norm

        self.vel[0] *= self.launch_speed
        self.vel[1] *= self.launch_speed

        self.pos = list(self.character.rect.center)
        self.rect.center = self.pos
        self.pickable = False

        self.image_angle = 0

    def disable(self):
        self.enabled = False
        self.image = self.image_empty
        self.rect = self.image.get_rect()
        self.vel = [0, 0]

    def hit(self, source):
        if isinstance(source, Minion):
            return
        if self.enabled and self.pickable:
            self.character.get_sword()
            self.disable()

    def update_wall_collision(self, dt):
        if self.rect.x < const.WALL_THICKNESS:
            self.rect.x = const.WALL_THICKNESS + 1
            self.pos[0] = self.rect.centerx
            self.vel[0] = -self.vel[0]
        if self.rect.x + self.rect.width >= const.REAL_WIDTH - const.WALL_THICKNESS:
            self.rect.x = const.REAL_WIDTH - const.WALL_THICKNESS - self.rect.width - 1
            self.pos[0] = self.rect.centerx
            self.vel[0] = -self.vel[0]
        if self.rect.y < const.WALL_THICKNESS:
            self.rect.y = const.WALL_THICKNESS + 1
            self.pos[1] = self.rect.centery
            self.vel[1] = -self.vel[1]
        if self.rect.y + self.rect.height >= const.REAL_HEIGHT - const.WALL_THICKNESS:
            self.rect.y = const.REAL_HEIGHT - const.WALL_THICKNESS - self.rect.height - 1
            self.pos[1] = self.rect.centery
            self.vel[1] = -self.vel[1]

    def update(self, dt):
        if not self.enabled:
            if self.character.sword_slip:
                self.character.sword_slip = False
                self.character.remove_sword()
                self.enable()
            return

        self.image_angle += 3 * math.hypot(self.vel[0], self.vel[1]) * dt
        if self.image_angle > 360:
            self.image_angle -= 360
        self.image = pygame.transform.rotate(self.image_sword, self.image_angle)

        self.vel[0] += - self.vel[0] * self.friction_coeff * dt
        self.vel[1] += - self.vel[1] * self.friction_coeff * dt
        if abs(self.vel[0]) < 1:
            self.vel[0] = 0
        if abs(self.vel[1]) < 1:
            self.vel[1] = 0
        if abs(self.vel[0]) < self.pickable_speed and abs(self.vel[1]) < self.pickable_speed:
            self.pickable = True
        self.pos[0] += self.vel[0] * dt
        self.pos[1] += self.vel[1] * dt
        self.update_wall_collision(dt)
        self.rect = self.image.get_rect()
        self.rect.center = self.pos
